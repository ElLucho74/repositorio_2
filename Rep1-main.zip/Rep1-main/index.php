<?php
echo "Soy el mapa soy el mapa soy el mapa del index";
?>
